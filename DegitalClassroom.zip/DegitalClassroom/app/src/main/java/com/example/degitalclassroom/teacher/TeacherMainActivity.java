package com.example.degitalclassroom.teacher;

import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

import com.example.degitalclassroom.R;
import com.example.degitalclassroom.teacher.fragment.TeaEventFragment;
import com.example.degitalclassroom.teacher.fragment.TeaHomeFragment;
import com.example.degitalclassroom.teacher.fragment.TeaNotificationFragment;
import com.example.degitalclassroom.teacher.fragment.TeaReportFragment;

public class TeacherMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_main);

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation_);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        loadFragment(new TeaHomeFragment());
    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            Fragment fragment;
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    //   toolbar.setTitle("Home");
                    fragment = new TeaHomeFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_report:
                    // toolbar.setTitle("report");
                    fragment = new TeaReportFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_notification:
                    // toolbar.setTitle("notification");
                    fragment = new TeaNotificationFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_event:
                    // toolbar.setTitle("event");
                    fragment = new TeaEventFragment();
                    loadFragment(fragment);
                    return true;
            }
            return false;
        }
    };

    private void loadFragment(Fragment fragment) {
        // load fragment
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_container, fragment);
        transaction.commit();
    }

}