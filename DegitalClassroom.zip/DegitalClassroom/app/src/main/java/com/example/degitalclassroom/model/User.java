package com.example.degitalclassroom.model;

public class User {
}
